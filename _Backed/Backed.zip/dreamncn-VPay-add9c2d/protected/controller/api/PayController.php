<?php
namespace app\controller\api;
/*
 * 自带的订单处理页面
 * */

class PayController extends BaseController
{


    public function actionIndex(){}


}