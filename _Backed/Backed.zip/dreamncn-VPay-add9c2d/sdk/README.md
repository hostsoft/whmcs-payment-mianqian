# SDK说明

1. 使用前务必修改`sdk/pay/config.php`第8-10行，配置成您在后台设置的地址。
2. `pay`文件夹是内置的工具类，可以直接使用。
3. 其他对接或配置问题请参考[这里](https://doc.dreamn.cn/doc/Vpay开发文档/)
4. 如果您不需要，可以删除sdk文件夹