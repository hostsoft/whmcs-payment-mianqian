<?php
/**
 * Alipay.php
 * Created By Dreamn.
 * Date : 2020/5/5
 * Time : 3:21 下午
 * Description :  支付宝模拟网页刷新取订单
 */
class Alipay{

}